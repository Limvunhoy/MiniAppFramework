#!/bin/sh

#  build_xcframework.sh
#  MiniAppFrameworkHost
#
#  Created by Vunhoy Lim on 31/7/25.
#


set -euo pipefail

SCHEME="MiniAppFrameworkHost"
CONFIGURATION="Release"
OUTPUT_DIR="./build"
FRAMEWORK_NAME="MiniAppFrameworkHost"

# Clean previous builds
rm -rf "$OUTPUT_DIR"
mkdir -p "$OUTPUT_DIR"

echo "🔍 Detecting architecture..."
ARCH=$(uname -m)
echo "👉 Detected architecture: $ARCH"

# Archive for iOS Device
echo "📦 Archiving for iOS Device..."
xcodebuild archive \
  -scheme "$SCHEME" \
  -configuration "$CONFIGURATION" \
  -destination "generic/platform=iOS" \
  -archivePath "$OUTPUT_DIR/ios_devices.xcarchive" \
  SKIP_INSTALL=NO \
  BUILD_LIBRARY_FOR_DISTRIBUTION=YES

# Setup simulator architectures based on machine
SIM_ARCHS="x86_64"
if [ "$ARCH" == "arm64" ]; then
  SIM_ARCHS="arm64 x86_64"
fi

echo "📦 Archiving for iOS Simulator ($SIM_ARCHS)..."
xcodebuild archive \
  -scheme "$SCHEME" \
  -configuration "$CONFIGURATION" \
  -destination "generic/platform=iOS Simulator" \
  -archivePath "$OUTPUT_DIR/ios_simulator.xcarchive" \
  ARCHS="$SIM_ARCHS" \
  SKIP_INSTALL=NO \
  BUILD_LIBRARY_FOR_DISTRIBUTION=YES

# Create .xcframework
echo "🧱 Creating XCFramework..."
xcodebuild -create-xcframework \
  -framework "$OUTPUT_DIR/ios_devices.xcarchive/Products/Library/Frameworks/$FRAMEWORK_NAME.framework" \
  -framework "$OUTPUT_DIR/ios_simulator.xcarchive/Products/Library/Frameworks/$FRAMEWORK_NAME.framework" \
  -output "$OUTPUT_DIR/$FRAMEWORK_NAME.xcframework"

# Zip the .xcframework
echo "🗜️ Zipping XCFramework..."
ZIP_PATH="$OUTPUT_DIR/$FRAMEWORK_NAME.xcframework.zip"
rm -f "$ZIP_PATH"
cd "$OUTPUT_DIR"
zip -r "$FRAMEWORK_NAME.xcframework.zip" "$FRAMEWORK_NAME.xcframework"
cd -

echo "✅ XCFramework zipped at: $ZIP_PATH"

# Compute checksum for the zipped xcframework
echo "🔐 Computing checksum..."
CHECKSUM=$(swift package compute-checksum "$ZIP_PATH")
echo "Checksum: $CHECKSUM"

# Generate Package.swift template
PACKAGE_SWIFT="$OUTPUT_DIR/Package.swift"
cat > "$PACKAGE_SWIFT" <<EOF
// swift-tools-version:5.3
import PackageDescription

let package = Package(
    name: "$FRAMEWORK_NAME",
    platforms: [
        .iOS(.v13)
    ],
    products: [
        .library(
            name: "$FRAMEWORK_NAME",
            targets: ["$FRAMEWORK_NAME"]
        ),
    ],
    targets: [
        .binaryTarget(
            name: "$FRAMEWORK_NAME",
            url: "https://your.domain.com/$FRAMEWORK_NAME.xcframework.zip",
            checksum: "$CHECKSUM"
        ),
    ]
)
EOF

echo "📦 Package.swift template generated at $PACKAGE_SWIFT"
echo "🔔 Remember to upload '$FRAMEWORK_NAME.xcframework.zip' to your HTTPS server and update the URL in Package.swift!"
