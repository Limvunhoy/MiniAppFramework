//
//  MiniAppFrameworkHost.h
//  MiniAppFrameworkHost
//
//  Created by Vunhoy Lim on 31/7/25.
//

#import <Foundation/Foundation.h>

//! Project version number for MiniAppFrameworkHost.
FOUNDATION_EXPORT double MiniAppFrameworkHostVersionNumber;

//! Project version string for MiniAppFrameworkHost.
FOUNDATION_EXPORT const unsigned char MiniAppFrameworkHostVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MiniAppFrameworkHost/PublicHeader.h>


